# mxraidctl

`mxraidctl` is a small SPDK RAID5/RAID5F management CLI. All implementation files live in this directory and talk to `spdk_tgt` through JSON-RPC.

## Quick Start

Run from the repository root:

```bash
python3 -m mxraidctl.mxraidctl --help
mxraidctl/bin/mxraidctl --help
```

Bind only selected NVMe devices:

```bash
sudo bash mxraidctl/scripts/spdk_setup.sh /dev/nvme1n1 /dev/nvme2n1
```

Start SPDK manually:

```bash
build/bin/spdk_tgt -m 0xF -r /var/tmp/spdk.sock
```

Create physical drives from PCIe NVMe controllers:

```bash
mxraidctl/bin/mxraidctl create pd --name Nvme0 --traddr /dev/nvme1n1
mxraidctl/bin/mxraidctl create pd --name Nvme1 --traddr /dev/nvme2n1
mxraidctl/bin/mxraidctl create pd --name Nvme2 --traddr /dev/nvme3n1
mxraidctl/bin/mxraidctl create pd --name Nvme3 --traddr /dev/nvme4n1
```

Create RAID5F:

```bash
mxraidctl/bin/mxraidctl create dg \
  --name raid5_0 \
  --level 5f \
  --strip-size-kb 64 \
  --base-bdevs Nvme0n1,Nvme1n1,Nvme2n1,Nvme3n1
```

Export as ublk:

```bash
mxraidctl/bin/mxraidctl export ublk raid5_0 --ublk-id 0 --num-queues 2 --queue-depth 128
```

Export as NVMe-oF TCP:

```bash
mxraidctl/bin/mxraidctl export nvmeof raid5_0 \
  --traddr 192.168.1.10 \
  --trsvcid 4420 \
  --nqn nqn.2026-05.io.mxraid:raid5_0
```

## Command Shape

```text
mxraidctl scan
mxraidctl list pd|dg|vd|export
mxraidctl describe pd|dg|vd|export <name>
mxraidctl create pd --name Nvme0 --traddr /dev/nvme1n1
mxraidctl create dg --name raid5_0 --level 5f --base-bdevs Nvme0n1,Nvme1n1,Nvme2n1
mxraidctl delete pd Nvme0
mxraidctl delete dg raid5_0
mxraidctl export ublk <bdev> --ublk-id 0
mxraidctl unexport ublk --ublk-id 0
mxraidctl export nvmeof <bdev> --traddr <ip> --trsvcid 4420
mxraidctl unexport nvmeof --nqn <nqn>
mxraidctl save --output /etc/mxraid/current.json
mxraidctl restore --input /etc/mxraid/current.json
mxraidctl service start|stop|restart|status
```

Use `--format json` when scripting.

## systemd

1. Copy or install the files:

```bash
sudo bash mxraidctl/install.sh
```

2. Edit `/etc/mxraid/mxraid.env`.

3. Enable the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mxraid-spdk.service
```
