#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause

set -euo pipefail

prefix=${PREFIX:-/usr/local}
unit_dir=${SYSTEMD_UNIT_DIR:-/etc/systemd/system}
env_dir=${MXRAID_ENV_DIR:-/etc/mxraid}
tool_dir=$(readlink -f "$(dirname "$0")")
lib_dir=${MXRAIDCTL_LIB_DIR:-"$prefix/lib/mxraidctl"}

install -d "$prefix/bin"
install -d "$lib_dir"
cp -R "$tool_dir/mxraidctl" "$lib_dir/"
cp -R "$tool_dir/scripts" "$lib_dir/"

cat > "$prefix/bin/mxraidctl" <<EOF
#!/usr/bin/env bash
PYTHONPATH="$lib_dir" exec python3 -m mxraidctl "\$@"
EOF
chmod 0755 "$prefix/bin/mxraidctl"

install -d "$env_dir"
if [[ ! -e "$env_dir/mxraid.env" ]]; then
	install -m 0644 "$tool_dir/systemd/mxraid.env.example" "$env_dir/mxraid.env"
fi

install -d "$unit_dir"
install -m 0644 "$tool_dir/systemd/mxraid-spdk.service" "$unit_dir/mxraid-spdk.service"

echo "Installed mxraidctl to $prefix/bin/mxraidctl"
echo "Installed mxraidctl library to $lib_dir"
echo "Installed systemd unit to $unit_dir/mxraid-spdk.service"
echo "Review $env_dir/mxraid.env, then run: systemctl daemon-reload"
