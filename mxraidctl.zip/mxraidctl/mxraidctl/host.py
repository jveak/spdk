# SPDX-License-Identifier: BSD-3-Clause

import os
from pathlib import Path


def is_bdf(value):
    parts = value.split(":")
    if len(parts) != 3 or "." not in parts[2]:
        return False
    bus, slot_func = parts[2].split(".", 1)
    return (
        len(parts[0]) == 4
        and len(parts[1]) == 2
        and len(bus) == 2
        and len(slot_func) == 1
        and all(_is_hex(part) for part in (parts[0], parts[1], bus, slot_func))
    )


def _is_hex(value):
    try:
        int(value, 16)
        return True
    except ValueError:
        return False


def normalize_block_name(device):
    path = Path(device)
    if str(path).startswith("/dev/"):
        if not path.exists():
            raise ValueError(f"{device} does not exist")
        name = path.resolve().name
    else:
        name = device

    sys_block = Path("/sys/class/block") / name
    if not sys_block.exists():
        raise ValueError(f"{device} is not a block device")

    if (sys_block / "partition").exists():
        name = sys_block.resolve().parent.name

    if not name.startswith("nvme") or "n" not in name:
        raise ValueError(f"{device} is not an NVMe namespace")
    return name


def resolve_nvme_to_bdf(device):
    if is_bdf(device):
        if not (Path("/sys/bus/pci/devices") / device).exists():
            raise ValueError(f"{device} is not present under /sys/bus/pci/devices")
        return device

    name = normalize_block_name(device)
    sys_path = (Path("/sys/class/block") / name / "device").resolve()
    for parent in (sys_path, *sys_path.parents):
        if is_bdf(parent.name) and (Path("/sys/bus/pci/devices") / parent.name).exists():
            pci_class = Path("/sys/bus/pci/devices") / parent.name / "class"
            if pci_class.exists() and pci_class.read_text(encoding="utf-8").strip() == "0x010802":
                return parent.name

    ctrl = name.rsplit("n", 1)[0]
    address = Path("/sys/class/nvme") / ctrl / "address"
    if address.exists():
        value = address.read_text(encoding="utf-8").strip()
        if is_bdf(value):
            return value

    raise ValueError(f"could not resolve {device} to a PCI NVMe BDF")


def scan_host_nvme():
    rows = []
    block_root = Path("/sys/class/block")
    if not block_root.exists():
        return rows

    for entry in sorted(block_root.iterdir(), key=lambda item: item.name):
        name = entry.name
        if not name.startswith("nvme") or "n" not in name or (entry / "partition").exists():
            continue
        try:
            bdf = resolve_nvme_to_bdf(name)
        except ValueError:
            bdf = ""
        model = _read_first(entry / "device" / "model", entry / "device" / "device" / "model")
        serial = _read_first(entry / "device" / "serial", entry / "device" / "device" / "serial")
        size = _read_first(entry / "size")
        rows.append({
            "device": f"/dev/{name}",
            "bdf": bdf,
            "model": model,
            "serial": serial,
            "sectors": size,
        })
    return rows


def _read_first(*paths):
    for path in paths:
        try:
            return Path(path).read_text(encoding="utf-8").strip()
        except OSError:
            continue
    return ""


def tool_root_from_this_file():
    return Path(__file__).resolve().parents[1]
