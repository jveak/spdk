# SPDX-License-Identifier: BSD-3-Clause

import json
import time

from .rpc import RPCError, call_ignoring


def attach_nvme(client, name, traddr, trtype="PCIe", **kwargs):
    params = {"name": name, "trtype": trtype, "traddr": traddr}
    params.update({key: value for key, value in kwargs.items() if value is not None})
    return client.call("bdev_nvme_attach_controller", params)


def detach_nvme(client, name, **kwargs):
    params = {"name": name}
    params.update({key: value for key, value in kwargs.items() if value is not None})
    return client.call("bdev_nvme_detach_controller", params)


def get_bdevs(client, name=None):
    params = {}
    if name:
        params["name"] = name
    return client.call("bdev_get_bdevs", params)


def create_raid(client, name, level, base_bdevs, strip_size_kb, superblock=False, parity_cache=False):
    params = {
        "name": name,
        "raid_level": level,
        "base_bdevs": base_bdevs,
        "strip_size_kb": strip_size_kb,
    }
    if superblock:
        params["superblock"] = True
    if parity_cache:
        params["parity_cache"] = True
    return client.call("bdev_raid_create", params)


def delete_raid(client, name):
    return client.call("bdev_raid_delete", {"name": name})


def list_raids(client, category="all"):
    return client.call("bdev_raid_get_bdevs", {"category": category})


def ensure_ublk_target(client, cpumask=None, disable_user_copy=False):
    params = {}
    if cpumask:
        params["cpumask"] = cpumask
    if disable_user_copy:
        params["disable_user_copy"] = True
    return call_ignoring(
        client,
        "ublk_create_target",
        params,
        ignored_fragments=("already", "exist"),
    )


def export_ublk(client, bdev_name, ublk_id, num_queues=1, queue_depth=128):
    return client.call("ublk_start_disk", {
        "bdev_name": bdev_name,
        "ublk_id": ublk_id,
        "num_queues": num_queues,
        "queue_depth": queue_depth,
    })


def unexport_ublk(client, ublk_id):
    return client.call("ublk_stop_disk", {"ublk_id": ublk_id})


def list_ublk(client, ublk_id=None):
    params = {}
    if ublk_id is not None:
        params["ublk_id"] = ublk_id
    return client.call("ublk_get_disks", params)


def ensure_nvmf_transport(client, trtype):
    return call_ignoring(
        client,
        "nvmf_create_transport",
        {"trtype": trtype},
        ignored_fragments=("already", "exist"),
    )


def export_nvmeof(client, bdev_name, nqn, trtype, traddr, trsvcid, serial, adrfam=None, allow_any_host=True):
    ensure_nvmf_transport(client, trtype)
    call_ignoring(
        client,
        "nvmf_create_subsystem",
        {
            "nqn": nqn,
            "serial_number": serial,
            "allow_any_host": allow_any_host,
        },
        ignored_fragments=("already", "exist"),
    )
    call_ignoring(
        client,
        "nvmf_subsystem_add_ns",
        {"nqn": nqn, "namespace": {"bdev_name": bdev_name}},
        ignored_fragments=("already", "exist"),
    )
    listen_address = {"trtype": trtype, "traddr": traddr, "trsvcid": trsvcid}
    if adrfam:
        listen_address["adrfam"] = adrfam
    call_ignoring(
        client,
        "nvmf_subsystem_add_listener",
        {"nqn": nqn, "listen_address": listen_address},
        ignored_fragments=("already", "exist"),
    )
    return {"nqn": nqn, "bdev": bdev_name, "listener": listen_address}


def unexport_nvmeof(client, nqn, trtype=None, traddr=None, trsvcid=None, adrfam=None):
    if trtype and traddr:
        listen_address = {"trtype": trtype, "traddr": traddr}
        if trsvcid:
            listen_address["trsvcid"] = trsvcid
        if adrfam:
            listen_address["adrfam"] = adrfam
        call_ignoring(
            client,
            "nvmf_subsystem_remove_listener",
            {"nqn": nqn, "listen_address": listen_address},
            ignored_fragments=("not found", "no listener"),
        )
    return client.call("nvmf_delete_subsystem", {"nqn": nqn})


def list_nvmf(client):
    return client.call("nvmf_get_subsystems", {})


def save_config(client, indent=2, subsystems=None):
    root = {"subsystems": []}
    subsystem_rows = client.call("framework_get_subsystems", {})
    dependencies = {}
    for row in subsystem_rows:
        name = row["subsystem"]
        dependencies[name] = {name}
        for dep in row.get("depends_on", []):
            dependencies[name].update(dependencies.get(dep, {dep}))

    if subsystems:
        to_print = set()
        for name in subsystems.split(","):
            to_print.update(dependencies.get(name, {name}))
    else:
        to_print = set(dependencies)

    for row in subsystem_rows:
        name = row["subsystem"]
        if name not in to_print:
            continue
        root["subsystems"].append({
            "subsystem": name,
            "config": client.call("framework_get_config", {"name": name}),
        })
    return json.dumps(root, indent=indent, ensure_ascii=False) + "\n"


def load_config(client, config):
    allowed = client.call("rpc_get_methods", {"include_aliases": True})
    subsystems = [item for item in config.get("subsystems", []) if item.get("config")]
    for subsystem in subsystems:
        for item in subsystem.get("config", []):
            if item.get("method") not in allowed:
                raise RPCError(f"unknown RPC method in config: {item.get('method')}")

    pending = subsystems
    while pending:
        current = client.call("rpc_get_methods", {"current": True, "include_aliases": True})
        progressed = False
        for subsystem in list(pending):
            config_items = subsystem["config"]
            for item in list(config_items):
                if item.get("method") not in current:
                    continue
                client.call(item["method"], item.get("params", {}))
                config_items.remove(item)
                progressed = True
            if not config_items:
                pending.remove(subsystem)
        if "framework_start_init" in current:
            client.call("framework_start_init", {})
            progressed = True
        if not progressed:
            break
        time.sleep(0.1)

    if pending:
        skipped = [item.get("method") for sub in pending for item in sub.get("config", [])]
        raise RPCError(f"some config items were skipped: {', '.join(skipped)}")


def summarize_bdevs(bdevs):
    rows = []
    for bdev in bdevs or []:
        rows.append({
            "name": bdev.get("name", ""),
            "product": bdev.get("product_name", ""),
            "block_size": bdev.get("block_size", ""),
            "num_blocks": bdev.get("num_blocks", ""),
            "claimed": bdev.get("claimed", ""),
        })
    return rows


def summarize_raids(raids):
    rows = []
    for raid in raids or []:
        rows.append({
            "name": raid.get("name", raid.get("raid_bdev", "")),
            "level": raid.get("raid_level", raid.get("level", "")),
            "state": raid.get("state", ""),
            "strip_kb": raid.get("strip_size_kb", ""),
            "base_bdevs": summarize_base_bdevs(raid),
        })
    return rows


def summarize_base_bdevs(raid):
    for key in ("base_bdevs", "base_bdevs_list"):
        value = raid.get(key)
        if isinstance(value, list):
            names = []
            for item in value:
                if isinstance(item, dict):
                    names.append(item.get("name", item.get("base_bdev", "")))
                else:
                    names.append(str(item))
            return " ".join(name for name in names if name)
        if value:
            return str(value)
    return ""
