# SPDX-License-Identifier: BSD-3-Clause

import json
from pathlib import Path


EMPTY_STATE = {
    "physical_drives": {},
    "drive_groups": {},
    "exports": {},
}


class StateStore:
    def __init__(self, path):
        self.path = Path(path)
        self.data = self._load()

    def _load(self):
        if not self.path.exists():
            return json.loads(json.dumps(EMPTY_STATE))
        with self.path.open("r", encoding="utf-8") as fd:
            data = json.load(fd)
        for key, value in EMPTY_STATE.items():
            data.setdefault(key, json.loads(json.dumps(value)))
        return data

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as fd:
            json.dump(self.data, fd, indent=2, ensure_ascii=False)
            fd.write("\n")

    def put(self, section, name, value):
        self.data[section][name] = value
        self.save()

    def delete(self, section, name):
        self.data.get(section, {}).pop(name, None)
        self.save()

    def get(self, section, name, default=None):
        return self.data.get(section, {}).get(name, default)
