# SPDX-License-Identifier: BSD-3-Clause

import copy
import json
import os
import socket
import time


class RPCError(Exception):
    pass


class SPDKClient:
    def __init__(self, address="/var/tmp/spdk.sock", port=5260, timeout=60.0, retries=0):
        self.address = address
        self.port = port
        self.timeout = timeout
        self.retries = retries
        self.sock = None
        self.recv_buf = ""
        self.request_id = 0
        self._connect()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def _connect(self):
        last_error = None
        for attempt in range(self.retries + 1):
            try:
                self.sock = self._open_socket()
                return
            except OSError as exc:
                last_error = exc
                if attempt < self.retries:
                    time.sleep(0.2)

        raise RPCError(
            f"could not connect to SPDK RPC endpoint {self.address}: {last_error}"
        )

    def _open_socket(self):
        if self.address.startswith("/") or os.path.exists(self.address):
            if not hasattr(socket, "AF_UNIX"):
                raise OSError("Unix domain sockets are not supported on this platform")
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(self.address)
            return sock

        family = socket.AF_INET6 if ":" in self.address else socket.AF_INET
        sock = socket.socket(family, socket.SOCK_STREAM)
        sock.connect((self.address, self.port))
        return sock

    def close(self):
        if self.sock is None:
            return
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.sock.close()
        self.sock = None

    def call(self, method, params=None):
        if self.sock is None:
            raise RPCError("RPC client is closed")
        if self.timeout <= 0:
            raise RPCError("timeout must be greater than zero")

        self.request_id += 1
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self.request_id,
        }
        if params:
            request["params"] = copy.deepcopy(params)

        payload = json.dumps(request).encode("utf-8")
        self.sock.sendall(payload)
        response = self._recv_one()

        if response.get("id") != self.request_id:
            raise RPCError(
                f"mismatched RPC id for {method}: expected {self.request_id}, "
                f"got {response.get('id')}"
            )
        if "error" in response:
            raise RPCError(
                "RPC error while calling "
                f"{method}: {json.dumps(response['error'], ensure_ascii=False)}"
            )
        return response.get("result")

    def _recv_one(self):
        start = time.monotonic()
        response = self._try_decode()
        while response is None:
            remaining = self.timeout - (time.monotonic() - start)
            if remaining <= 0:
                raise RPCError(f"timeout waiting for RPC response: {self.recv_buf}")
            self.sock.settimeout(remaining)
            try:
                data = self.sock.recv(4096)
            except socket.timeout as exc:
                raise RPCError(f"timeout waiting for RPC response: {self.recv_buf}") from exc
            if not data:
                raise RPCError(f"connection closed with partial response: {self.recv_buf}")
            self.recv_buf += data.decode("utf-8")
            response = self._try_decode()
        return response

    def _try_decode(self):
        buf = self.recv_buf.lstrip()
        if not buf:
            self.recv_buf = ""
            return None
        try:
            response, idx = json.JSONDecoder().raw_decode(buf)
        except ValueError:
            self.recv_buf = buf
            return None
        self.recv_buf = buf[idx:]
        return response


def call_ignoring(client, method, params=None, ignored_fragments=None):
    try:
        return client.call(method, params)
    except RPCError as exc:
        message = str(exc).lower()
        for fragment in ignored_fragments or ():
            if fragment.lower() in message:
                return None
        raise
