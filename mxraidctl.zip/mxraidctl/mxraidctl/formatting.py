# SPDX-License-Identifier: BSD-3-Clause

import json


def print_json(data):
    print(json.dumps(data, indent=2, ensure_ascii=False))


def print_result(data, output_format="table"):
    if output_format == "json":
        print_json(data)
        return

    if data is None:
        return
    if isinstance(data, list):
        print_table(data)
        return
    if isinstance(data, dict):
        print_dict(data)
        return
    print(data)


def print_dict(data):
    for key in sorted(data):
        value = data[key]
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False)
        print(f"{key}: {value}")


def print_table(rows):
    if not rows:
        print("No resources found.")
        return
    if not all(isinstance(row, dict) for row in rows):
        for row in rows:
            print(row)
        return

    keys = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)

    widths = {key: len(key) for key in keys}
    rendered = []
    for row in rows:
        item = {}
        for key in keys:
            value = row.get(key, "")
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False)
            else:
                value = "" if value is None else str(value)
            item[key] = value
            widths[key] = max(widths[key], len(value))
        rendered.append(item)

    print("  ".join(key.ljust(widths[key]) for key in keys))
    print("  ".join("-" * widths[key] for key in keys))
    for row in rendered:
        print("  ".join(row[key].ljust(widths[key]) for key in keys))
