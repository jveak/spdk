# SPDX-License-Identifier: BSD-3-Clause

import argparse
import json
import subprocess
import sys
from pathlib import Path

from . import __version__
from .formatting import print_dict, print_json, print_result, print_table
from .host import tool_root_from_this_file, resolve_nvme_to_bdf, scan_host_nvme
from .rpc import RPCError, SPDKClient
from .state import StateStore
from . import spdk


DEFAULT_RPC_SOCKET = "/var/tmp/spdk.sock"
DEFAULT_STATE_FILE = "/var/lib/mxraid/state.json"
DEFAULT_UNIT = "mxraid-spdk.service"


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 2

    try:
        return args.func(args)
    except (RPCError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


def build_parser():
    parser = argparse.ArgumentParser(
        prog="mxraidctl",
        description="Manage SPDK RAID5/RAID5F resources through JSON-RPC.",
    )
    parser.add_argument("--rpc-socket", default=DEFAULT_RPC_SOCKET, help="SPDK RPC Unix socket")
    parser.add_argument("--rpc-addr", help="SPDK RPC TCP address; overrides --rpc-socket")
    parser.add_argument("--rpc-port", type=int, default=5260, help="SPDK RPC TCP port")
    parser.add_argument("--timeout", type=float, default=60.0, help="RPC timeout in seconds")
    parser.add_argument("--conn-retries", type=int, default=3, help="RPC connection retry count")
    parser.add_argument("--format", choices=("table", "json"), default="table", help="Output format")
    parser.add_argument("--state-file", default=DEFAULT_STATE_FILE, help="mxraidctl state file")
    parser.add_argument("--no-state", action="store_true", help="Do not update mxraidctl state file")

    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("version", help="Display mxraidctl and SPDK version information")
    p.set_defaults(func=cmd_version)

    p = sub.add_parser("scan", help="Scan host NVMe devices and SPDK bdevs")
    p.set_defaults(func=cmd_scan)

    p = sub.add_parser("list", help="List resources")
    p.add_argument("resource", nargs="?", default="all", choices=("all", "pd", "dg", "vd", "export"))
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("describe", help="Describe one resource")
    p.add_argument("resource", choices=("pd", "dg", "vd", "export"))
    p.add_argument("name")
    p.set_defaults(func=cmd_describe)

    create = sub.add_parser("create", help="Create a resource").add_subparsers(dest="create_resource", required=True)
    p = create.add_parser("pd", help="Attach an NVMe controller as SPDK bdevs")
    p.add_argument("--name", required=True, help="SPDK NVMe controller name, for example Nvme0")
    p.add_argument("--traddr", required=True, help="PCI BDF or /dev/nvmeXnY")
    p.add_argument("--trtype", default="PCIe", help="Transport type, default PCIe")
    p.add_argument("--adrfam")
    p.add_argument("--trsvcid")
    p.add_argument("--subnqn")
    p.add_argument("--hostnqn")
    p.add_argument("--num-io-queues", type=int)
    p.set_defaults(func=cmd_create_pd)

    p = create.add_parser("dg", help="Create RAID drive group")
    p.add_argument("--name", required=True, help="RAID bdev name")
    p.add_argument("--level", default="5f", help="RAID level, for example 5, 5f, 0, 1")
    p.add_argument("--base-bdevs", required=True, help="Comma or space separated base bdev names")
    p.add_argument("--strip-size-kb", type=int, default=64)
    p.add_argument("--superblock", action="store_true")
    p.add_argument("--parity-cache", action="store_true")
    p.set_defaults(func=cmd_create_dg)

    delete = sub.add_parser("delete", help="Delete a resource").add_subparsers(dest="delete_resource", required=True)
    p = delete.add_parser("pd", help="Detach an NVMe controller")
    p.add_argument("name")
    p.set_defaults(func=cmd_delete_pd)

    p = delete.add_parser("dg", help="Delete RAID drive group")
    p.add_argument("name")
    p.set_defaults(func=cmd_delete_dg)

    export = sub.add_parser("export", help="Export a bdev").add_subparsers(dest="export_type", required=True)
    p = export.add_parser("ublk", help="Export bdev as /dev/ublkbN")
    p.add_argument("bdev")
    p.add_argument("--ublk-id", type=int, required=True)
    p.add_argument("--num-queues", type=int, default=1)
    p.add_argument("--queue-depth", type=int, default=128)
    p.add_argument("--cpumask")
    p.add_argument("--disable-user-copy", action="store_true")
    p.set_defaults(func=cmd_export_ublk)

    p = export.add_parser("nvmeof", help="Export bdev through NVMe-oF")
    p.add_argument("bdev")
    p.add_argument("--nqn")
    p.add_argument("--trtype", default="tcp")
    p.add_argument("--traddr", required=True)
    p.add_argument("--trsvcid", default="4420")
    p.add_argument("--adrfam")
    p.add_argument("--serial")
    p.add_argument("--no-allow-any-host", action="store_true")
    p.set_defaults(func=cmd_export_nvmeof)

    unexport = sub.add_parser("unexport", help="Remove an export").add_subparsers(dest="export_type", required=True)
    p = unexport.add_parser("ublk", help="Stop ublk export")
    p.add_argument("--ublk-id", type=int, required=True)
    p.set_defaults(func=cmd_unexport_ublk)

    p = unexport.add_parser("nvmeof", help="Delete NVMe-oF subsystem export")
    p.add_argument("--nqn", required=True)
    p.add_argument("--trtype")
    p.add_argument("--traddr")
    p.add_argument("--trsvcid")
    p.add_argument("--adrfam")
    p.set_defaults(func=cmd_unexport_nvmeof)

    p = sub.add_parser("save", help="Save live SPDK config")
    p.add_argument("--output", "-o")
    p.add_argument("--subsystems")
    p.add_argument("--indent", type=int, default=2)
    p.set_defaults(func=cmd_save)

    p = sub.add_parser("restore", help="Restore SPDK config")
    p.add_argument("--input", "-i", required=True)
    p.set_defaults(func=cmd_restore)

    service = sub.add_parser("service", help="Control mxraid systemd service").add_subparsers(
        dest="service_action", required=True
    )
    for action in ("start", "stop", "restart", "status", "enable", "disable"):
        p = service.add_parser(action)
        p.add_argument("--unit", default=DEFAULT_UNIT)
        p.set_defaults(func=cmd_service)

    setup = sub.add_parser("setup", help="Bind or reset selected NVMe devices").add_subparsers(
        dest="setup_action", required=True
    )
    for action in ("bind", "reset", "status"):
        p = setup.add_parser(action)
        p.add_argument("devices", nargs="*")
        p.set_defaults(func=cmd_setup)

    return parser


def client_from_args(args):
    address = args.rpc_addr or args.rpc_socket
    return SPDKClient(address, port=args.rpc_port, timeout=args.timeout, retries=args.conn_retries)


def state_from_args(args):
    if args.no_state:
        return None
    return StateStore(args.state_file)


def print_ok(args, data):
    print_result(data, args.format)
    return 0


def cmd_version(args):
    data = {"mxraidctl": __version__}
    try:
        with client_from_args(args) as client:
            data["spdk"] = client.call("spdk_get_version", {})
    except RPCError as exc:
        data["spdk_error"] = str(exc)
    return print_ok(args, data)


def cmd_scan(args):
    data = {"host_nvme": scan_host_nvme()}
    try:
        with client_from_args(args) as client:
            data["spdk_bdevs"] = spdk.summarize_bdevs(spdk.get_bdevs(client))
    except RPCError as exc:
        data["spdk_error"] = str(exc)

    if args.format == "json":
        print_json(data)
    else:
        print("Host NVMe")
        print_table(data["host_nvme"])
        print()
        if "spdk_error" in data:
            print(f"SPDK bdevs: {data['spdk_error']}")
        else:
            print("SPDK bdevs")
            print_table(data["spdk_bdevs"])
    return 0


def cmd_list(args):
    with client_from_args(args) as client:
        if args.resource == "pd":
            return print_ok(args, spdk.summarize_bdevs(spdk.get_bdevs(client)))
        if args.resource in ("dg", "vd"):
            return print_ok(args, spdk.summarize_raids(spdk.list_raids(client)))
        if args.resource == "export":
            return print_ok(args, list_exports(client))

        data = {
            "physical_drives": spdk.summarize_bdevs(spdk.get_bdevs(client)),
            "drive_groups": spdk.summarize_raids(spdk.list_raids(client)),
            "exports": list_exports(client),
        }

    if args.format == "json":
        print_json(data)
    else:
        print("Physical drives")
        print_table(data["physical_drives"])
        print()
        print("Drive groups")
        print_table(data["drive_groups"])
        print()
        print("Exports")
        print_table(data["exports"])
    return 0


def cmd_describe(args):
    with client_from_args(args) as client:
        if args.resource == "pd":
            data = spdk.get_bdevs(client, args.name)
        elif args.resource in ("dg", "vd"):
            raids = spdk.list_raids(client)
            data = [raid for raid in raids if args.name in (raid.get("name"), raid.get("raid_bdev"))]
        else:
            exports = list_exports(client)
            data = [item for item in exports if args.name in (str(item.get("id")), item.get("name"), item.get("nqn"))]
    return print_ok(args, data)


def cmd_create_pd(args):
    traddr = resolve_nvme_to_bdf(args.traddr) if args.trtype.lower() == "pcie" else args.traddr
    with client_from_args(args) as client:
        result = spdk.attach_nvme(
            client,
            name=args.name,
            traddr=traddr,
            trtype=args.trtype,
            adrfam=args.adrfam,
            trsvcid=args.trsvcid,
            subnqn=args.subnqn,
            hostnqn=args.hostnqn,
            num_io_queues=args.num_io_queues,
        )
    store = state_from_args(args)
    if store:
        store.put("physical_drives", args.name, {"name": args.name, "trtype": args.trtype, "traddr": traddr})
    return print_ok(args, {"created": result, "controller": args.name, "traddr": traddr})


def cmd_create_dg(args):
    base_bdevs = parse_name_list(args.base_bdevs)
    with client_from_args(args) as client:
        spdk.create_raid(
            client,
            name=args.name,
            level=args.level,
            base_bdevs=base_bdevs,
            strip_size_kb=args.strip_size_kb,
            superblock=args.superblock,
            parity_cache=args.parity_cache,
        )
    store = state_from_args(args)
    if store:
        store.put("drive_groups", args.name, {
            "name": args.name,
            "level": args.level,
            "base_bdevs": base_bdevs,
            "strip_size_kb": args.strip_size_kb,
        })
    return print_ok(args, {"created": args.name, "level": args.level, "base_bdevs": base_bdevs})


def cmd_delete_pd(args):
    with client_from_args(args) as client:
        result = spdk.detach_nvme(client, args.name)
    store = state_from_args(args)
    if store:
        store.delete("physical_drives", args.name)
    return print_ok(args, {"deleted": args.name, "result": result})


def cmd_delete_dg(args):
    with client_from_args(args) as client:
        result = spdk.delete_raid(client, args.name)
    store = state_from_args(args)
    if store:
        store.delete("drive_groups", args.name)
    return print_ok(args, {"deleted": args.name, "result": result})


def cmd_export_ublk(args):
    with client_from_args(args) as client:
        spdk.ensure_ublk_target(client, cpumask=args.cpumask, disable_user_copy=args.disable_user_copy)
        result = spdk.export_ublk(
            client,
            bdev_name=args.bdev,
            ublk_id=args.ublk_id,
            num_queues=args.num_queues,
            queue_depth=args.queue_depth,
        )
    store = state_from_args(args)
    if store:
        store.put("exports", f"ublk:{args.ublk_id}", {
            "type": "ublk",
            "bdev": args.bdev,
            "ublk_id": args.ublk_id,
        })
    return print_ok(args, {"type": "ublk", "bdev": args.bdev, "ublk_id": args.ublk_id, "device": result})


def cmd_unexport_ublk(args):
    with client_from_args(args) as client:
        result = spdk.unexport_ublk(client, args.ublk_id)
    store = state_from_args(args)
    if store:
        store.delete("exports", f"ublk:{args.ublk_id}")
    return print_ok(args, {"unexported": f"ublk:{args.ublk_id}", "result": result})


def cmd_export_nvmeof(args):
    nqn = args.nqn or f"nqn.2026-05.io.mxraid:{args.bdev}"
    serial = args.serial or serial_from_name(args.bdev)
    with client_from_args(args) as client:
        result = spdk.export_nvmeof(
            client,
            bdev_name=args.bdev,
            nqn=nqn,
            trtype=args.trtype,
            traddr=args.traddr,
            trsvcid=args.trsvcid,
            serial=serial,
            adrfam=args.adrfam,
            allow_any_host=not args.no_allow_any_host,
        )
    store = state_from_args(args)
    if store:
        store.put("exports", f"nvmeof:{nqn}", {
            "type": "nvmeof",
            "bdev": args.bdev,
            "nqn": nqn,
            "trtype": args.trtype,
            "traddr": args.traddr,
            "trsvcid": args.trsvcid,
        })
    return print_ok(args, result)


def cmd_unexport_nvmeof(args):
    with client_from_args(args) as client:
        result = spdk.unexport_nvmeof(
            client,
            nqn=args.nqn,
            trtype=args.trtype,
            traddr=args.traddr,
            trsvcid=args.trsvcid,
            adrfam=args.adrfam,
        )
    store = state_from_args(args)
    if store:
        store.delete("exports", f"nvmeof:{args.nqn}")
    return print_ok(args, {"unexported": args.nqn, "result": result})


def cmd_save(args):
    with client_from_args(args) as client:
        payload = spdk.save_config(client, indent=args.indent, subsystems=args.subsystems)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload, end="")
    return 0


def cmd_restore(args):
    config = json.loads(Path(args.input).read_text(encoding="utf-8"))
    with client_from_args(args) as client:
        spdk.load_config(client, config)
    return print_ok(args, {"restored": args.input})


def cmd_service(args):
    cmd = ["systemctl", args.service_action, args.unit]
    completed = subprocess.run(cmd, check=False)
    return completed.returncode


def cmd_setup(args):
    mode = "config" if args.setup_action == "bind" else args.setup_action
    script = tool_root_from_this_file() / "scripts" / "spdk_setup.sh"
    cmd = ["bash", str(script), mode, *args.devices]
    completed = subprocess.run(cmd, check=False)
    return completed.returncode


def list_exports(client):
    rows = []
    try:
        ublk_rows = spdk.list_ublk(client, None)
        if isinstance(ublk_rows, dict):
            ublk_rows = [ublk_rows]
        for item in ublk_rows or []:
            rows.append({
                "type": "ublk",
                "id": item.get("ublk_id", item.get("id", "")) if isinstance(item, dict) else "",
                "name": item.get("bdev_name", item.get("bdev", "")) if isinstance(item, dict) else str(item),
                "nqn": "",
                "listener": "",
            })
    except RPCError:
        pass

    try:
        for subsystem in spdk.list_nvmf(client) or []:
            nqn = subsystem.get("nqn", "")
            listeners = subsystem.get("listen_addresses", subsystem.get("listeners", []))
            ns_list = subsystem.get("namespaces", [])
            bdevs = []
            for ns in ns_list:
                bdev = ns.get("bdev_name") or ns.get("name")
                if bdev:
                    bdevs.append(bdev)
            rows.append({
                "type": "nvmeof",
                "id": "",
                "name": ",".join(bdevs),
                "nqn": nqn,
                "listener": json.dumps(listeners, ensure_ascii=False),
            })
    except RPCError:
        pass
    return rows


def parse_name_list(value):
    names = []
    for chunk in value.replace(",", " ").split():
        chunk = chunk.strip()
        if chunk:
            names.append(chunk)
    if not names:
        raise ValueError("empty bdev list")
    return names


def serial_from_name(name):
    clean = "".join(ch for ch in name.upper() if ch.isalnum())
    return (clean or "MXRAID")[:20].ljust(8, "0")
