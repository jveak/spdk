#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
#
# Resolve explicit NVMe namespace paths to PCI BDFs, then delegate actual
# hugepage allocation and PCI binding to SPDK's scripts/setup.sh.

set -euo pipefail

tool_dir=$(readlink -f "$(dirname "$0")/..")
spdk_root=$(readlink -f "$tool_dir/..")
spdk_setup="$spdk_root/scripts/setup.sh"

function usage() {
	cat <<-EOF
	Usage:
	  $(basename "$0") [config] <nvme-dev-or-bdf> [<nvme-dev-or-bdf> ...]
	  $(basename "$0") reset <nvme-dev-or-bdf> [<nvme-dev-or-bdf> ...]
	  $(basename "$0") status [<nvme-dev-or-bdf> ...]

	Examples:
	  sudo $(basename "$0") /dev/nvme1n1
	  sudo $(basename "$0") /dev/nvme1n1 /dev/nvme2n1
	  sudo DRIVER_OVERRIDE=vfio-pci HUGEMEM=8192 $(basename "$0") /dev/nvme1n1
	  sudo $(basename "$0") reset /dev/nvme1n1
	EOF
}

function die() {
	echo "ERROR: $*" >&2
	exit 1
}

function is_bdf() {
	[[ $1 =~ ^[[:xdigit:]]{4}:[[:xdigit:]]{2}:[[:xdigit:]]{2}\.[0-7]$ ]]
}

function block_name() {
	local dev=$1
	local name

	if [[ $dev == /dev/* ]]; then
		[[ -e $dev ]] || die "$dev does not exist"
		name=$(basename "$(readlink -f "$dev")")
	else
		name=$dev
	fi

	[[ -e /sys/class/block/$name ]] || die "$dev is not a block device"

	if [[ -e /sys/class/block/$name/partition ]]; then
		name=$(basename "$(dirname "$(readlink -f "/sys/class/block/$name")")")
	fi

	[[ $name =~ ^nvme[0-9]+n[0-9]+$ ]] || die "$dev is not an NVMe namespace"
	echo "$name"
}

function bdf_from_path() {
	local path=$1
	local base class

	while [[ $path != "/" && -n $path ]]; do
		base=${path##*/}
		if is_bdf "$base" && [[ -e /sys/bus/pci/devices/$base ]]; then
			class=$(< "/sys/bus/pci/devices/$base/class")
			if [[ $class == 0x010802 ]]; then
				echo "$base"
				return 0
			fi
		fi
		path=${path%/*}
	done
	return 1
}

function nvme_bdf() {
	local dev=$1
	local name path ctrl address

	if is_bdf "$dev"; then
		[[ -e /sys/bus/pci/devices/$dev ]] || die "$dev is not present under /sys/bus/pci/devices"
		echo "$dev"
		return 0
	fi

	name=$(block_name "$dev")
	path=$(readlink -f "/sys/class/block/$name/device")
	if bdf_from_path "$path"; then
		return 0
	fi

	ctrl=${name%n*}
	if [[ -r /sys/class/nvme/$ctrl/address ]]; then
		address=$(< "/sys/class/nvme/$ctrl/address")
		if is_bdf "$address"; then
			echo "$address"
			return 0
		fi
	fi

	die "could not resolve $dev to a PCI NVMe BDF"
}

[[ -x $spdk_setup ]] || die "SPDK setup script not found or not executable: $spdk_setup"

mode=config
case "${1:-}" in
	-h|--help|help)
		usage
		exit 0
		;;
	config|reset|status)
		mode=$1
		shift
		;;
esac

if [[ $mode != status && $# -eq 0 ]]; then
	usage >&2
	die "at least one NVMe device or BDF is required"
fi

bdfs=()
for dev in "$@"; do
	bdfs+=("$(nvme_bdf "$dev")")
done

if ((${#bdfs[@]} > 0)); then
	export PCI_ALLOWED="${PCI_ALLOWED:+$PCI_ALLOWED }${bdfs[*]}"
	export DEV_TYPE="${DEV_TYPE:-NVME}"
	echo "Using PCI_ALLOWED=$PCI_ALLOWED"
fi

exec "$spdk_setup" "$mode"
